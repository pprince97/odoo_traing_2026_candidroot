from odoo import models, fields, api

class Appointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'Appointment'

    hospital_id = fields.Many2one('hospital.hospital', ondelete='restrict',string='Hospital')
    patient_id = fields.Many2one('res.partner', ondelete='restrict',string='Patient')
    department_id = fields.Many2one('hospital.department', ondelete='restrict',string='Department')
    department_name = fields.Char(default=department_id.name, string='Department')
    doctor_id = fields.Many2one('res.partner', ondelete='restrict',string='Doctor')
    appointment_date = fields.Date(string='Appointment Date', default=fields.Date.today())
    patient_address = fields.Char(string='Patient Address', readonly=True)
    patient_dob = fields.Char(string='Patient Date of Birth', readonly=True)
    patient_age = fields.Char(string='Patient Age', readonly=True)
    patient_mobile = fields.Char(string='Patient Mobile', readonly=True)
    patient_email = fields.Char(string='Patient Email', readonly=True)
    status = fields.Selection([('new','New'),('in_progress','In Progress'),('done','Done'),('cancelled','Cancelled')], string='Status', default='new')
    appointment_count = fields.Integer()

    @api.onchange('hospital_id')
    def _onchange_department(self):
        self.patient_id = self.env['res.partner'].search([(self.hospital_id.id, 'in', 'hospital_ids.ids')])
        self.department_id = self.env['hospital.department'].search([(self.hospital_id.id, 'in', 'hospital_ids.ids')])
        self.doctor_id = self.env['res.partner'].search([(self.hospital_id.id, '=', 'hospital_id')])


    def show_appointments(self):
        self.appointment_count = self.env['hospital.hospital'].search_count([(self.patient_id, 'in', 'patient_ids.ids')])
        dom = {
            'name': self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.appointment',
            'view_mode': 'list,form',
            'domain': ['doctor_id', '=', self.id],
            'target': 'new'
        }
        if self.appointment_count == 1:
            dom['view_mode'] = 'form'
        return dom

    @api.onchange('patient_id')
    def _onchange_patient(self):
        self.patient_address = self.env.browse(self.patient_id).street
        self.patient_dob = self.env.browse(self.patient_id).dob
        self.patient_age = self.env.browse(self.patient_id).age
        self.patient_mobile = self.env.browse(self.patient_id).phone
        self.patient_email = self.env.browse(self.patient_id).email
