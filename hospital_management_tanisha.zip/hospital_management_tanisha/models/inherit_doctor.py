from odoo import models,fields,api

class InheritDoctor(models.Model):
    _inherit = 'res.partner'

    doctor_id = fields.Char(string='Doctor ID')
    department_id = fields.Many2one('hospital.department', ondelete='restrict' ,string='Department')
    experience_year = fields.Integer(string='Experience years')
    speciality_description = fields.Text(string='Speciality/Description')
    did = fields.Integer(default=1)
    appointment_count = fields.Integer()
    appointment_ids = fields.One2many('hospital.appointment', 'doctor_id', string='Appointments')
    hospital_id = fields.Many2one('hospital.hospital', ondelete='restrict' ,string='Hospital')

    @api.model_create_multi
    def create(self, vals):
        res = super(InheritDoctor, self).create(vals)
        did_rev=str(self.did)[::-1]
        while len(did_rev)<4:
            did_rev+='0'
        did_rev='D'+did_rev[::-1]
        self.pid+=1
        for rec in res:
            rec.write({
                'patient_id': did_rev,
            })
        return res

    # @api.depends('dob')
    # def _compute_age(self):
    #

    def doctor_appointments(self):
        self.appointment_count = self.env['hospital.appointment'].search_count([('doctor_id', '=', self.id)])
        dom = {
            'name': self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.appointment',
            'view_mode': 'list,form',
            'domain': ['doctor_id', '=', self.id],
            'target': 'new'
        }
        if self.appointment_count == 1:
            dom['view_mode'] = 'form'
        return dom