from odoo import models,fields

class Department(models.Model):
    _name = "hospital.department"
    _description = "Department Model"

    name = fields.Char(string="Name")
    color = fields.Integer(string="Color")
