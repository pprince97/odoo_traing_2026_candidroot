from odoo import fields,models

class DepartmentWizard(models.TransientModel):
    _name = 'department.wizard'
    _description = 'Department Wizard'

    name = fields.Char(string="Name")
    color = fields.Integer(string="Color")

    def wizard_create(self):
        res= self.env['hospital.department'].create({'name':self.name,'color':self.color})
        return res
