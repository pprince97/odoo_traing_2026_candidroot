{
    'name': 'Library Management',
    'version': '19.0.1',
    'author': 'Amitkumar',
    'description': 'library management system',

    'depends': ['base', 'web', 'contacts', 'mail', 'website', 'website_sale', 'sale_management', 'portal'],

    'data': [
        'demo/demo_web.xml',
        'security/library_security.xml',
        'security/ir.model.access.csv',
        'wizard/cancellation_wizard_view.xml',
        'wizard/borrow_history_wizard_view.xml',
        'report/borrow_request_report.xml',
        'report/borrow_history_report.xml',
        'views/res_config_settings_view.xml',
        'views/books_view.xml',
        'views/students_view.xml',
        'views/librarians_view.xml',
        'views/borrow_request_view.xml',
        'views/borrow_request_line_view.xml',
        'views/file_history_view.xml',
        'views/user_profile.xml',
        'views/web_templates.xml',
        'views/web_header.xml',
        'views/web_footer.xml',
        'views/web_shop_view.xml',
        'views/web_user_profile.xml',
    ],

    'demo': [
        'demo/demo_view.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'library_management/static/src/views/fields/binary/inherit_view.xml',
            'library_management/static/src/views/fields/binary/inherit_history.js',
        ],

        'web.assets_frontend': [
            'library_management/static/src/css/website_view.scss',
            'library_management/static/src/js/profile.js',
            # 'web_editor/static/src/xml/**/*',
            # 'html_editor/static/src/xml/**/*',
        ],
    },

    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
