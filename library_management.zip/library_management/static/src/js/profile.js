/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";
import { rpc } from "@web/core/network/rpc";
console.log("Christmas Theme loaded");


publicWidget.registry.UserProfile = publicWidget.widget.extend({
    selector: '#wrap',

    start() {
        console.log("Christmas Theme loaded");
        console.log("Christmas  loaded");
        console.log("Christmas Theme ");
        return this._super(...arguments);
    }
});
