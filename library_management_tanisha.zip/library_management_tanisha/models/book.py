from odoo import models,fields,api

class LibraryBook(models.Model):
    _name = 'library.book'
    _description = 'Books'

    name = fields.Char(string='Name')
    barcode = fields.Char(string='Barcode')
    description = fields.Text(string='Description')
    currency_id = fields.Many2one(comodel_name='res.currency',string="Foreign Currency")
    currency = fields.Monetary(compute='_compute_currency', store=True, readonly=False,string="Currency",currency_field='currency_id')
    state = fields.Selection([('published', 'Published'),('unpublished', 'Unpublished')],string='State',default='published')
    category = fields.Selection([('knowledge', 'Knowledge'),('novel', 'Novel'),('story', 'Story'),('science', 'Science'),('history', 'History'),('comic','Comic')],string='Category',default='knowledge')
    available_copies = fields.Integer(string='Available copies')
    stock = fields.Integer(string='Stock')
    cover_image = fields.Image(string='Cover Image')
    borrow_price = fields.Float(string='Borrow Price (per day)')
    max_day_limit = fields.Integer(string='Maximum Day Limit')
    borrow_request_line_ids = fields.One2many(comodel_name='library.borrow.request.lines',inverse_name='book_id')
    borrow_history_ids = fields.Many2many(comodel_name='book.history.wizard', relation='book_borrow_history_rel', column1='book_id', column2='book_borrow_id', string='Borrow Books')

    @api.depends_context('company')
    def _compute_currency(self):
        self.currency = self.env['res.company'].currency_id


