from odoo import models,fields,api

class LibraryBorrowRequest(models.Model):
    _name = 'library.borrow.request'
    _description = 'Borrow Request'
    _rec_name = 'serial_no'

    serial_no = fields.Char(string='Serial number')
    student_id = fields.Many2one(comodel_name='res.partner',string='Student')
    librarian_id = fields.Many2one(comodel_name='res.partner',string='Librarian')
    state = fields.Selection([('draft', 'Draft'),('issued', 'Issued'),('returned', 'Returned'),('canceled', 'Canceled')],string='State',default='draft')
    issue_date = fields.Date(string='Issue date')
    return_date = fields.Date(string='Return date')
    fine_amount = fields.Float(string='Fine amount')
    total_amount = fields.Float(string='Total amount')
    canceled_date = fields.Date(string='Canceled date')
    borrow_request_line_ids = fields.One2many(comodel_name='library.borrow.request.lines',inverse_name='borrow_request_id')
    cancellation_reason = fields.Text(string='Cancellation reason')

    @api.model_create_multi
    def create(self, vals_list):
        if self.env.context.get('borrow_request'):
            vals_list[0]['serial_no'] = self.env['ir.sequence'].next_by_code('borrow.request.seq') or 'New'
        res = super(LibraryBorrowRequest, self).create(vals_list)
        return res

    def state_draft(self):
        self.state = 'draft'

    def state_issue(self):
        self.state = 'issued'
        self.issue_date = fields.Date.today()

    def state_returned(self):
        self.state = 'returned'
        self.return_date = fields.Date.today()

    def state_canceled(self):
        self.state = 'canceled'
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'request.cancel.wizard',
            'view_mode': 'form',
            'target': 'new',
        }


