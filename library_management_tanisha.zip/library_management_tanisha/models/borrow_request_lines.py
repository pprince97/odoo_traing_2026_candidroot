from odoo import models,fields,api

class LibraryBorrowRequestLines(models.Model):
    _name = 'library.borrow.request.lines'
    _description = 'Borrow Request Lines'
    _rec_name = 'book_id'

    book_id = fields.Many2one(comodel_name='library.book',string='Book')
    quantity = fields.Integer(string='Quantity')
    amount_per_unit_per_day = fields.Float(string='Amount per unit per day')
    issue_date = fields.Date(string='Issue date')
    return_date = fields.Date(string='Return date')
    fine_amount = fields.Float(string='Fine amount')
    total_amount = fields.Float(string='Total amount')
    issue_days = fields.Integer(string='Issue days')
    borrow_request_id = fields.Many2one(comodel_name='library.borrow.request',string='Borrow Request')

