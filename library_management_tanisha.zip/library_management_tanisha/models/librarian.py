from odoo import models,fields,api

class LibraryLibrarian(models.Model):
    _inherit = 'res.partner'

    gender = fields.Selection([('male', 'Male'),('female', 'Female')],string='Gender',default='male')
    l = fields.Char(string='Librarian ?')
    borrow_request_ids = fields.One2many(comodel_name='library.borrow.request', inverse_name='librarian_id', string='Borrow Requests')

    @api.model_create_multi
    def create(self, vals_list):
        res = super(LibraryLibrarian, self).create(vals_list)
        if self.env.context.get('librarian'):
            vals_list[0]['l'] = 'librarian'
        return res

