from odoo import models,fields,api

class LibraryStudent(models.Model):
    _inherit = 'res.partner'

    gender = fields.Selection([('male', 'Male'),('female', 'Female')],string='Gender',default='male')
    s = fields.Char(string='Student ?')
    borrow_request_ids = fields.One2many(comodel_name='library.borrow.request',inverse_name='student_id',string='Borrow Requests')
    book_history_id = fields.Many2many(comodel_name='book.history.wizard',relation='book_student_rel', column1='student_id',column2='book_borrow_id',string='Book Borrow history')

    @api.model_create_multi
    def create(self, vals_list):
        res = super(LibraryStudent, self).create(vals_list)
        if self.env.context.get('student'):
           vals_list[0]['s'] = 'student'
        return res
