from odoo import models, fields, api


class BookHistoryWizard(models.TransientModel):
    _name = 'book.history.wizard'
    _description = 'Book History Wizard'

    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')
    is_return_date = fields.Boolean(string='Is return date? ')
    student_ids = fields.Many2many(comodel_name='res.partner', relation='book_student_rel', column1='book_borrow_id',column2='student_id', string='Students')
    book_ids = fields.Many2many(comodel_name='library.book', relation='book_borrow_history_rel', column1='book_borrow_id',column2='book_id', string = 'Books')

    def print_history(self):
        return True
