from odoo import models,fields,api

class RequestCancelWizard(models.TransientModel):
    _name = 'request.cancel.wizard'
    _description = 'Request Cancel Wizard'

    cancellation_reason = fields.Text(string='Cancellation Reason')

    def submit(self):
        return {
            'type': 'ir.actions.act_window',
            'target': 'self',
            'res_model': 'library.borrow.request',
            'view_mode': 'list,form',
        }

