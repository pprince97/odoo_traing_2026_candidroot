/** @odoo-module **/

import {Component, xml} from "@odoo/owl";
import {registry} from "@web/core/registry";

// import { ProductCard } from "./product_card";

export class Root extends Component {
    static components = "owl_template.ProductCard";

    static template = xml`
        <div class="product-grid">
          <t t-foreach="this.products" t-as="p" t-key="p.id">
            <ProductCard t-props="{
                name: p.name,
                price: p.price,
                image: p.image
            }"/>
          </t>
        </div>
    `;

    setup() {
        this.products = [
            {id: 1, name: "Wireless Headphones", price: 79.99, image: "🎧"},
            {id: 2, name: "Mechanical Keyboard", price: 129.99, image: "⌨️"},
            {id: 3, name: "USB-C Hub", price: 49.99},
            {id: 4, name: "Webcam HD", price: 59.99, image: "📷"},
        ];
    }
}

registry.category("actions").add("owl_template.product_action", Root);