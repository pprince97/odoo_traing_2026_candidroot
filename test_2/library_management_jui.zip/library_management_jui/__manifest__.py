{
    'name':'Library Management',
    'version':'0.1',
    'author':'jui',
    'category':'Uncategorized',

    'summary':"Library management summary",
    'description':"Library management description",

    'website':"http://www.library.com",
    'license':'LGPL-3',
    'installable':True,
    'application':True,

    'depends': ['base'],
    'data':[
        'security/library_groups.xml',
        'security/ir_rules.xml',
        'security/ir.model.access.csv',
        'data/borrow_request_sequence.xml',
        'demo/books_demo.xml',
        'demo/student_demo.xml',
        'demo/borrow_request_demo.xml',
        'report/borrow_request_reciept_report.xml',
        'wizard/book_borrow_history_wizard.xml',
        'wizard/borrow_request_cancel_wizard.xml',
        'views/res_config_settings.xml',
        'views/books_view.xml',
        'views/borrow_request_view.xml',
        'views/librarian_view.xml',
        'views/student_view.xml',
    ]
}