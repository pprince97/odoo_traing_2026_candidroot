from odoo import models,fields,api
from odoo.exceptions import ValidationError

class BooksModel(models.Model):
    _name = 'library.books'
    _description = 'Books'

    name = fields.Char(string='Name', required=True)
    barcode = fields.Char(string='Barcode', required=True)
    description = fields.Text(string='Description')
    currency_id = fields.Many2one('res.currency')
    state = fields.Selection([('published', 'Published'), ('unpublished', 'Unpublished')],string='State',default='unpublished')
    category = fields.Char(string='Category')
    available_copies = fields.Integer(string='Available copies')
    stock = fields.Integer(string='Stock')
    cover_image = fields.Image(string='Cover Image')
    borrow_price = fields.Float(string='Borrow Price (per day)',required=True)
    maximum_day_limit = fields.Integer(string='Maximum Day Limit')

    borrowed_count = fields.Integer(string='Borrowed Count')

    @api.model_create_multi
    def create(self, vals):
        for rec in vals:
            if self.env['library.books'].search([('barcode','=',rec['barcode'])]):
                print(rec['barcode'])
                raise ValidationError("Barcode must be unique")
        res = super(BooksModel, self).create(vals)
        return res

    def history_of_borrowed(self):
        borrow_history = self.env['library.book_borrow_history_wizard']
        self.borrowed_count = borrow_history.search_count([
            ("book_ids", "in", self.id),
        ])
        return {
            'name': "Borrow History",
            'type': 'ir.actions.act_window',
            'view_mode': 'list,form',
            'res_model': 'library.book_borrow_history_wizard',
            'target': 'self',
            'domain': [
                ("book_ids", "in", self.id),
            ],
        }
