from email.policy import default

from odoo import fields,models,api
from odoo.exceptions import ValidationError


class BorrowRequestLines(models.Model):
    _name = 'library.borrow_request_lines'
    _description = 'Borrow Request Lines'
    _rec_name = 'book_id'

    book_id = fields.Many2one('library.books',string='Book',required=True)
    quantity = fields.Integer(string='Quantity',default=1)
    amount_per_unit = fields.Float(string='Amount Per Unit per Day', related='book_id.borrow_price', store=True)
    issue_date = fields.Date(string='Issue Date',required=True)
    return_date = fields.Date(string='Return Date', required=True)
    fine_amount = fields.Float(string='Fine Amount', compute='_compute_fine_amount', store=True)
    total_amount = fields.Float(string='Total Amount', compute='_compute_total_amount', store=True)
    issue_days = fields.Integer(string='Issue Days', compute='_compute_issue_days', store=True)

    borrow_request_id = fields.Many2one('library.borrow_request',string='Borrow Request')

    @api.model_create_multi
    def create(self, vals):
        for rec in vals:
            print(rec)
            res = self.env['library.books'].search([('id', '=', rec['book_id'])])
            res.available_copies -= rec['quantity']
        res = super(BorrowRequestLines, self).create(vals)
        return res

    @api.depends('issue_date','return_date')
    def _compute_issue_days(self):
        for rec in self:
            if rec.issue_date and rec.return_date:
                val = (rec.return_date - rec.issue_date).days
                print(val)
                if val >0:
                    rec.issue_days = val
                else:
                    rec.issue_days = 0
                if rec.issue_days > rec.book_id.maximum_day_limit:
                    raise ValidationError("This book can not be issued beyond max issue date limit")

    @api.depends('return_date')
    def _compute_fine_amount(self):
        for rec in self:
            if rec.return_date:
                fine_amount_config = rec.env['ir.config_parameter'].sudo().get_param('library_management_jui.fine_amount')
                days = fields.Date.today() - rec.return_date
                if days.days > 0:
                    rec.fine_amount = float(fine_amount_config) * days.days

                else:
                    rec.fine_amount = 0

    @api.depends('fine_amount','amount_per_unit','quantity','issue_days')
    def _compute_total_amount(self):
        for rec in self:
            rec.total_amount = (rec.amount_per_unit * rec.quantity * rec.issue_days) + rec.fine_amount

