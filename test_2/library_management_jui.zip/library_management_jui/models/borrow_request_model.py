from odoo import fields, models,api

class BorrowRequest(models.Model):
    _name = 'library.borrow_request'
    _description = 'Borrow requests'
    _rec_name = 'serial_number'

    serial_number = fields.Char(string='Serial Number', readonly=True)
    student_id = fields.Many2one('res.partner',string='Student',required=True,context={'default_is_student':1})
    librarian_id = fields.Many2one('res.partner',string='Librarian',context={'default_is_student':1})
    state = fields.Selection([('draft','Draft'),('issued','Issued'),('returned','Returned'),('canceled','Canceled')],string='State', default='draft')
    return_date = fields.Date(string='Return Date')
    issue_date = fields.Date(string='Issue Date')
    fine_amount = fields.Float(string='Fine Amount', compute='_compute_fine_amount',store=True)
    total_amount = fields.Float(string='Total Amount',compute='_compute_total_amount',store=True)
    canceled_date = fields.Date(string='Canceled Date')
    cancellation_reason = fields.Char(string='Cancellation Reason')

    borrow_request_lines_id = fields.One2many('library.borrow_request_lines','borrow_request_id',string='Borrow Request Lines')

    @api.model_create_multi
    def create(self, vals):
        for rec in vals:
            rec['serial_number'] = self.env['ir.sequence'].next_by_code('borrow.request.seq') or 'New'
        res = super(BorrowRequest, self).create(vals)
        return res

    @api.depends('borrow_request_lines_id')
    def _compute_total_amount(self):
        self.total_amount = 0
        if self.borrow_request_lines_id:
            for rec in self.borrow_request_lines_id:
                print(rec.total_amount)
                self.total_amount += rec.total_amount

    @api.depends('borrow_request_lines_id')
    def _compute_fine_amount(self):
        self.fine_amount = 0
        if self.borrow_request_lines_id:
            for rec in self.borrow_request_lines_id:
                print(rec.fine_amount)
                self.fine_amount += rec.fine_amount

    def draft_state(self):
        self.state = 'draft'
        self.issue_date = False

    def issued_state(self):
        self.state = 'issued'
        self.issue_date = fields.Date.today()
        for rec in self.borrow_request_lines_id:
            rec.issue_date = fields.Date.today()


    def returned_state(self):
        self.state = 'returned'
        self.return_date = fields.Date.today()
        for rec in self.borrow_request_lines_id:
            rec.book_id.available_copies +=1

    def canceled_state(self):
        self.state = 'canceled'
        self.canceled_date = fields.Date.today()
        for rec in self.borrow_request_lines_id:
            rec.book_id.available_copies +=1
        return {
            'name': 'Borrow request cancel',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'library.borrow_request_cancel_wizard',
            'target': 'new',
            'context': {'default_borrow_request_id': self.id}
        }

    def generate_report(self):
        return self.env.ref('library_management_jui.borrow_request_receipt_action').report_action(self.id)
