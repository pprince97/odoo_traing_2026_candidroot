from odoo import api, fields, models

class BookBorrowHistory(models.TransientModel):
    _name = 'library.book_borrow_history_wizard'
    _description = 'Book Borrow History'

    start_date = fields.Date('Start Date')
    end_date = fields.Date('End Date')
    is_return_date = fields.Boolean(string='Is Return Date')
    student_ids = fields.Many2many('res.partner','book_borrow_student_relation','book_borrow_id','student_id',string='Students')
    book_ids = fields.Many2many('library.books','book_borrow_relation','book_borrow_id','book_id',string='Books')

    borrow_request_lines_id = fields.Many2many('library.borrow_request_lines','borrow_request_history_relation','borrow_history_id','borrow_request_line_id',string='Borrow Request Lines')


    def print_history(self):
        pass
        # if self.is_return_date:
        #     return self.env.ref('library_management_jui.book_borrow_history_with_return_action').report_action(self.id)
        # else:
        #     return self.env.ref('library_management_jui.book_borrow_history_without_return_action').report_action(self.id)
