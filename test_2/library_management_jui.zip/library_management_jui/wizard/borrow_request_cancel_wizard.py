from odoo import api,fields,models,exceptions

class BorrowRequestCancel(models.TransientModel):
    _name = 'library.borrow_request_cancel_wizard'
    _description = 'Borrow Request Cancel'

    cancellation_reason =fields.Char(string='Cancellation Reason')
    borrow_request_id = fields.Many2one('library.borrow_request')

    def wizard_submit(self):
        res = self.env['library.borrow_request'].search([('id','=',self.borrow_request_id)])
        res.update({'cancellation_reason':self.cancellation_reason})